@extends('layouts.app')

@section('content')
	<h1>Android and Mobile</h1>
@endsection