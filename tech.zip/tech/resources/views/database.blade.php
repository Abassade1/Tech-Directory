@extends('layouts.app')

@section('content')
	<h1>Database management</h1>
@endsection