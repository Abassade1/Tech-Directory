
 @extends('layouts.app')

@section('content')

<section>
    <div class="card-group col-md-4 container">
      <div class="card">
        <img class="card-img-top" src="images/init_logo.png" alt="company logo">
        <div class="card-body">
          <h4 class="card-title">Init Limited </h4>
          <div class ="contact__list">
            <span class="glyphicon glyphicon-phone" aria-hidden="true"></span> +234-807-787-0008
            <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span> www.initng.com
            <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> info@init.com
            <p class="card-text">We have developed several web-based solutions for a wide variety of clients from different commercial sectors and the public sector.</p>
          </div> 
        </div>        
      </div>
    </div>

</section>  

@endsection


