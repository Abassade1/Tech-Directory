@extends('layouts.app')

@section('content')
	<h1>Tech Hub</h1>
@endsection