@extends('layouts.app')

@section('content')
	<h1>Web and software</h1>
@endsection