@extends('layouts.app')

@section('content')
	<h1>Tech Training centers</h1>
@endsection