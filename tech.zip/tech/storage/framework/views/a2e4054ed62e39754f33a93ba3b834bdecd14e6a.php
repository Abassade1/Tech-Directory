<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="featured__container">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="card-body">
                                        <span class="dashboard__icons glyphicon glyphicon-icon" aria-hidden="true"></span>
                                        <a href="http://127.0.0.1:8000/" class="btn btn-danger">Go Home</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="card-body">
                                         <span class="dashboard__icons glyphicon glyphicon-icon" aria-hidden="true"></span>
                                        <a href="http://127.0.0.1:8000/addcompany" class="btn btn-primary">ADD COMPANY</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="card">
                                    <div class="card-body">
                                         <span class="dashboard__icons glyphicon glyphicon-icon" aria-hidden="true"></span>
                                        <a href="#" class="btn btn-primary">SETTINGS</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>