<?php $__env->startSection('content'); ?>
	
<div class="col-md-6 col-md-offset-3 form__container">

	<form method="POST" action="/home">
		<?php echo e(csrf_field()); ?>


		<h3>ADD COMPANY</h3>
		<hr>
		<div class="form-group col-md-6">
			<label class="col-form-label" for="companyname">Company Name</label>
	    	<input type="companyname" class="form-control" id="companyname" placeholder="INITS Limited">
	  	</div>
	  	<div class="form-group col-md-6">
	    	<label class="col-form-label" for="contactperson">Contact Person</label>
	    	<input type="contactperson" class="form-control" id="contactperson" placeholder="Dennis">
	  	</div>
		
		<div class="form-row">
	    <div class="form-group col-md-6">
	    	<label for="email">Email</label>
	    	<input type="email" class="form-control" id="email" placeholder=" info@initsng.com">
	    </div>
	    
	  	<div class="form-group col-md-6">
	    	<label for ="number">Mobile contacts</label>
	    	<input type="number" class="form-control" id="number" placeholder="+234-807-787-008">
	  	</div>
	  	<div class="form-group col-md-6">
	    	<label for="address">Address</label>
	    	<input type="address" class="form-control" id="address" placeholder="Head Office:16, Majaro Street, Onike, Yaba, Lagos.">
	  	</div>
	  	<div class="form-group col-md-6">
	    	<label for="website">website</label>
	    	<input type="website" class="form-control" id="website" placeholder="http://initsng.com">
	  	</div>

	  	<div class="form-group col-md-6">
	     	<label for="location">Lagos</label>
	     	<select id="location" class="form-control">
	        	<option>Lagos</option>
	      	</select>
	    </div>
	    <div class="form-group col-md-6">
	      <label for="location">Office Location</label>
	      <select id="location" class="form-control">
	        <option selected>Office Location</option>
	        <option>Yaba</option>
	        <option>Onike</option>
	        <option>Victoria Island</option>
	        <option>Sabo</option>
	        <option>Ikeja</option>
	        <option>Allen</option>
	        <option>Lekki</option>
	        <option>Ikoyi</option>
	        <option>Ikorodu</option>
	      </select>
	    </div>
		<hr>
		<label>SERVICES</label>
		<div class="form-check">
			<label class="form-check-label">
			<input class="form-check-input" type="checkbox" value="">Web & Software
			</label>
		</div>
		<div class="form-check">
			<label class="form-check-label">
		    <input class="form-check-input" type="checkbox" value="">Database Management
		  	</label>
		</div>
		<div class="form-check">
			<label class="form-check-label">
		    <input class="form-check-input" type="checkbox" value="">Tech Training
		 	</label>
		</div>
		<div class="form-check">
		  	<label class="form-check-label">
		    <input class="form-check-input" type="checkbox" value="">Android & Mobile
		  	</label>
		</div>
		<div class="form-check">
		  	<label class="form-check-label">
		    <input class="form-check-input" type="checkbox" value="">Tech Hub
		  	</label>
		</div>
		<div class="form-group">
		    <label for="Business details">Business Distription</label>
		    <textarea class="form-control" id="business details" rows="3"></textarea>
		</div>
		<div class="form-group">
			<label for="companylogo">Company logo</label>
		    <input type="file" class="form-control-file" id="logo">
		</div>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>